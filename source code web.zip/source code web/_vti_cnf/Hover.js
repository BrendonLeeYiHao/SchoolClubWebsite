vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|02 Jul 2021 02:33:00 -0000
vti_extenderversion:SR|12.0.0.0
vti_author:SR|DESKTOP-72O504J\\brend
vti_modifiedby:SR|DESKTOP-72O504J\\brend
vti_timecreated:TR|02 Jul 2021 02:33:00 -0000
vti_cacheddtm:TX|02 Jul 2021 02:33:00 -0000
vti_filesize:IR|393
vti_backlinkinfo:VX|Group\\ 1\\ FDD\\ Assignment/nicolemodifyFDD30-6/FDD_Assignment\\ (29.6.2021)/functions.html
